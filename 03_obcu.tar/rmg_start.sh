#!/bin/bash

#
#
#DIR=$(dirname $(readlink -f $0))
#
#

SOURCE="${BASH_SOURCE[0]}"
while [ -h "$SOURCE" ]; do # resolve $SOURCE until the file is no longer a symlink
  DIR="$( cd -P "$( dirname "$SOURCE" )" && pwd )"
  SOURCE="$(readlink "$SOURCE")"
  [[ $SOURCE != /* ]] && SOURCE="$DIR/$SOURCE" # if $SOURCE was a relative symlink, we need to resolve it relative to the path where the symlink file was located
done
DIR="$( cd -P "$( dirname "$SOURCE" )" && pwd )"

REPOPATH=/opt/tpkg/
PWD=${PWD}
packageName=${DIR:${#REPOPATH}}

source ${REPOPATH}01_monitrc/bin/config.sh

for file in $(ls -1 ${REPOPATH} 2>/dev/null)
do
    if [ -d "${REPOPATH}${file}" ]; then
        lpackageName=${file}
        if [ -d "${REPOPATH}${file}/bin" ]; then
            if [[ ":${PATH}:" == *":${file}/bin:"* ]]; then
                echo "${file}/bin is already in PATH"
            else
                PATH=${PATH}:${REPOPATH}${file}/bin
            fi
        fi
        
        if [ "$lpackageName" = "$packageName" ]; then
            break
        fi
    fi
done


export PATH

mkdir -p ${VOLATILE_LOG_PATH}${packageName}
mkdir -p ${LOG_PATH}/${packageName}

cd $DIR

cd radiomanager
./radiomanager ./radiomng.ini ./zlogconfig.conf &

PID=$!
echo $PID >/var/run/radiomanager.pid

# 
#
