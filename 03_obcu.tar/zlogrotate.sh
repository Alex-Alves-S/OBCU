#!/bin/bash

LOGSFILE=`cat $1 | grep "\.log" | cut -d '"' -f 2 | uniq`
LOCKFILE1=`cat $1 | grep "rotate lock file" | cut -d '=' -f 2`
LOCKFILE=`echo ${LOCKFILE1}`


function dorotate
{
	local BASEFNAME=$1
	echo "renaming ${BASEFNAME}"
	TMPFILE=`mktemp`
	echo -e "${BASEFNAME} {\n\tsu\n\trotate 999\n\tdaily\n\tmissingok\n}" > ${TMPFILE}
	logrotate -f ${TMPFILE}
	rm ${TMPFILE}
}


if [ -e $LOCKFILE ]; then
	(
		flock -w 2 200
		RC=$?
		#file locked => roll
		if [ "$?" == "0" ]; then
			for f in $LOGSFILE; do
				dorotate $f
			done
		fi
	) 200>>${LOCKFILE}
fi
